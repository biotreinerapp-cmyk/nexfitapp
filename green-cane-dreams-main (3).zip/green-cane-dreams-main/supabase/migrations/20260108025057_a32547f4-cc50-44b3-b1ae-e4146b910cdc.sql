alter table public.running_club_activities
  add column if not exists caption text;